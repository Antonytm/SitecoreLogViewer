﻿window.onload = function () {
    console.log(1);
    var plugin = document.createElement("embed");
    plugin.setAttribute("type", "application/x-npapi-file-io");
    document.documentElement.appendChild(plugin);
    console.log(plugin.getPlatform());
    console.log(plugin.listFiles("C:\\inetpub\\wwwroot\\"));
    
    chrome.tabs.query({ 'active': true, 'lastFocusedWindow': true }, function (tabs) {
        var parser = document.createElement('a');
        parser.href = tabs[0].url;
        console.log(parser.host);
        console.log(plugin.lastFileByTemplate("C:\\inetpub\\wwwroot\\" + parser.host + "\\Data\\logs\\", "log*.txt"));
    });
}